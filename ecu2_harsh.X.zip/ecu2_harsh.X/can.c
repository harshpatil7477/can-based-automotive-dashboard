
/* ===================== can.c ===================== */
#include <xc.h>
#include "can.h"

typedef enum _CanOpMode {
    e_can_op_mode_normal = 0x00,
    e_can_op_mode_loop   = 0x40,
    e_can_op_mode_config = 0x80
} CanOpMode;

void init_can(void) {
    /* CAN_TX = RB2, CAN_RX = RB3 */
    TRISB2 = 0;
    TRISB3 = 1;

    CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config);
    while (CANSTAT != 0x80);

    ECANCON = 0x00;

    /* Bit timing - must be identical on every ECU */
    BRGCON1 = 0xE1;
    BRGCON2 = 0x1B;
    BRGCON3 = 0x03;

    RXFCON0 = 0x00;

    CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);
    while ((CANSTAT & 0xE0) != 0x00);

    /* Receive all messages, acceptance filters ignored (RXM1:RXM0 = 11) */
    RXB0CON = 0x60;
}

static uint16_t get_msg_id_std(void) {
    uint16_t id;

    id = ((RXB0SIDL >> 5) & 0x07) | ((uint16_t)RXB0SIDH << 3);
    return id;
}

static void set_msg_id_std(uint16_t id) {
    TXB0SIDL = (id & 0x07) << 5;
    TXB0SIDH = (id >> 3);
}

void can_transmit(uint16_t msg_id, const uint8_t *data, uint8_t len) {
    uint8_t *ptr;
    uint16_t timeout = 60000;

    if (len > 8)
        len = 8;

    /* wait until the previous frame is sent */
    while (TXB0REQ && --timeout);

    if (TXB0REQ)
    {
        TXB0REQ = 0;        /* abort stuck frame (e.g. no other node on bus) */
    }

    TXB0EIDH = 0x00;
    TXB0EIDL = 0x00;

    set_msg_id_std(msg_id);

    TXB0DLC = len;

    ptr = (uint8_t *) &TXB0D0;
    for (uint8_t i = 0; i < len; i++) {
        ptr[i] = data[i];
    }

    TXB0REQ = 1;
}

/* len = 0 means no data available. Caller must check len before using data */
void can_receive(uint16_t *msg_id, uint8_t *data, uint8_t *len) {
    uint8_t *ptr;

    if (RXB0FUL) {
        *msg_id = get_msg_id_std();
        *len = RXB0DLC & 0x0F;
        if (*len > 8)
            *len = 8;

        ptr = (uint8_t *) &RXB0D0;
        for (uint8_t i = 0; i < *len; i++) {
            data[i] = ptr[i];
        }

        COMSTAT &= ~0x80;
        RXB0FUL = 0;
        RXB0IF = 0;
    }
    else {
        *len = 0;
    }
}
