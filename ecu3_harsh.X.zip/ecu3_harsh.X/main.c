
#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"

static void init_leds(void)
{
    TRISB0 = 0;
    TRISB1 = 0;
    TRISB6 = 0;
    TRISB7 = 0;

    PORTB &= 0x3C;
}

static void init_config(void)
{
    init_clcd();
    init_can();
    init_leds();
    init_timer0();
}

void main(void)
{
    init_config();

    clcd_print("SPD  GR  RPM IND", LINE1(0));

    while (1)
    {
        process_canbus_data();
    }
}