#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad.h"

uint16_t get_speed()
{
    uint16_t speed;

    speed = ((unsigned long)read_adc(CHANNEL4) * 100) / 1023;

    if (speed > 100)
    {
        speed = 100;
    }

    return speed;
}
unsigned char get_gear_pos()
{
    static unsigned char gear = 'N';

    unsigned char key = read_digital_keypad(1);

    if (key == SWITCH1)
    {
        if(gear =='N'|| gear =='R')
        {
            gear ='1';
        }
        else if (gear < MAX_GEAR)
        {
            gear++;
        }
    }
    else if (key == SWITCH2)
    {
        if(gear =='N'|| gear =='R')
        {
            gear ='1';
        }
        else if (gear > MIN_GEAR)
        {
            gear--;
        }
    }
    else if (key == SWITCH3)
    {
        gear= 'R';
    }
    else if (key == SWITCH4)
    {
//        gear = 0;
        gear= 'N';
    }

    return gear;
}