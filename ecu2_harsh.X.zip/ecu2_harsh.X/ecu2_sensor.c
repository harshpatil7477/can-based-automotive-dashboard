
/* ===================== ecu2_sensor.c ===================== */
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"

volatile IndicatorStatus prev_ind_status = e_ind_off, cur_ind_status = e_ind_off;
volatile unsigned char led_state = LED_OFF;

/* ADC 0-1023 -> RPM 0-6000 (integer math, no float) */
uint16_t get_rpm(void)
{
    uint16_t adc_val = read_adc(RPM_ADC_CHANNEL);

    return (uint16_t)(((uint32_t)adc_val * 6000) / 1023);
}

/* SW1 = left, SW2 = right, SW3 = off, SW4 = parking (hazard).
 * Pressing the same key again turns it off */
IndicatorStatus process_indicator(void)
{
    unsigned char key = read_digital_keypad(STATE_CHANGE);

    if (key == SWITCH1)
    {
        cur_ind_status = (cur_ind_status == e_ind_left) ? e_ind_off : e_ind_left;
    }
    else if (key == SWITCH2)
    {
        cur_ind_status = (cur_ind_status == e_ind_right) ? e_ind_off : e_ind_right;
    }
    else if (key == SWITCH3)
    {
        cur_ind_status = e_ind_off;
    }
    else if (key == SWITCH4)
    {
        cur_ind_status = (cur_ind_status == e_ind_park) ? e_ind_off : e_ind_park;
    }

    return cur_ind_status;
}