
#include <xc.h>
#include "timer0.h"

volatile unsigned char timer0_tick_flag = 0;

void init_timer0(void)
{
    RCONbits.IPEN = 0;

    T08BIT = 0;
    T0CS = 0;

    PSA = 0;

    T0PS2 = 0;
    T0PS1 = 1;
    T0PS0 = 0;

    TMR0H = 0xE7;
    TMR0L = 0x96;

    TMR0IF = 0;
    TMR0IE = 1;

    GIE = 1;

    TMR0ON = 1;
}

void __interrupt() isr(void)
{
    if (TMR0IF)
    {
        TMR0H = 0xE7;
        TMR0L = 0x96;

        timer0_tick_flag = 1;

        TMR0IF = 0;
    }
}
