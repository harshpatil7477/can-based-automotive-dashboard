#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "uart.h"

void main(void)
{
    uint16_t speed;
    unsigned char gear;
    char str[4];

    init_adc();
    init_uart();
    init_digital_keypad();
    init_can();

    while (1)
    {
        speed = get_speed();
        gear = get_gear_pos();

        // Convert speed into 3-digit ASCII format
        str[0] = (speed / 100) + '0';
        str[1] = ((speed / 10) % 10) + '0';
        str[2] = (speed % 10) + '0';
        str[3] = '\0';

        // Display speed on UART
        puts("Speed: ");
        puts(str);
        puts(" km/h\r\n");

        // Display gear on UART
        puts("Gear: ");
        putch(gear);
        puts("\r\n");

        // Transmit speed and gear through CAN
        can_transmit(SPEED_MSG_ID, (uint8_t *)str, 3);
        can_transmit(GEAR_MSG_ID, (uint8_t *)&gear, 1);
    }
}