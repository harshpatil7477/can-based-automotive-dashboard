
#ifndef TIMER0_H
#define TIMER0_H

extern volatile unsigned char timer0_tick_flag;

void init_timer0(void);

#endif