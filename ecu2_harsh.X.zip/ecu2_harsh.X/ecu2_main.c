
/* ===================== ecu2_main.c ===================== */
#define _XTAL_FREQ 20000000      /* set to your real oscillator, only affects delay timing */

#include <xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"

#define BLINK_COUNT  250         /* loops (~1 ms each) per LED toggle -> ~250 ms */
#define SEND_COUNT   100         /* loops between periodic CAN sends -> ~100 ms  */

static void indicator_update_leds(void)
{
    LEFT_IND_OFF();
    RIGHT_IND_OFF();
    PARK_LED_OFF();

    if (led_state == LED_ON)
    {
        if (cur_ind_status == e_ind_left)
        {
            LEFT_IND_ON();
        }
        else if (cur_ind_status == e_ind_right)
        {
            RIGHT_IND_ON();
        }
        else if (cur_ind_status == e_ind_park)
        {
            LEFT_IND_ON();
            RIGHT_IND_ON();
            PARK_LED_ON();
        }
    }
}

static void init_ports(void)
{
    ADCON1 = 0x0A;          /* AN0-AN4 analog (AN4 = RPM pot), rest digital */
    TRISB  = TRISB & 0x2C;  /* RB0,RB1,RB4,RB6,RB7 = LED outputs; RB2/RB3 stay as CAN */
    PORTB  = PORTB & 0x2C;  /* LEDs off */
}

void main(void)
{
    uint16_t rpm;
    uint8_t  can_data[2];
    uint16_t blink_cnt = 0;
    uint16_t send_cnt = 0;
    unsigned char send_now;

    init_ports();
    init_adc();
    init_digital_keypad();
    init_can();

    while (1)
    {
        rpm = get_rpm();
        process_indicator();

        send_now = 0;

        /* ---------- Indicator changed: restart blink and send immediately ---------- */
        if (cur_ind_status != prev_ind_status)
        {
            prev_ind_status = cur_ind_status;
            led_state = LED_OFF;
            blink_cnt = 0;
            send_now = 1;
        }

        /* ---------- CAN send: on indicator change, and periodically ---------- */
        if (send_now || ++send_cnt >= SEND_COUNT)
        {
            send_cnt = 0;

            /* RPM: 2 bytes, high byte first */
            can_data[0] = (uint8_t)(rpm >> 8);
            can_data[1] = (uint8_t)(rpm & 0xFF);
            can_transmit(RPM_MSG_ID, can_data, 2);

            /* Indicator: 1 byte (0=off, 1=left, 2=right, 3=park) */
            can_data[0] = (uint8_t)cur_ind_status;
            can_transmit(INDICATOR_MSG_ID, can_data, 1);
        }

        /* ---------- Blink ---------- */
        if (cur_ind_status == e_ind_off)
        {
            led_state = LED_OFF;
        }
        else if (++blink_cnt >= BLINK_COUNT)
        {
            blink_cnt = 0;
            led_state = !led_state;
        }
        indicator_update_leds();

        __delay_ms(1);
    }
}