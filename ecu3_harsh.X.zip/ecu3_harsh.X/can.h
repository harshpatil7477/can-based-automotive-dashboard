
#ifndef CAN_H
#define CAN_H

#include <stdint.h>

#define CAN_SET_OPERATION_MODE_NO_WAIT(mode)    \
{                                               \
    CANCON &= 0x1F;                             \
    CANCON |= mode;                             \
}

void init_can(void);
void can_transmit(uint16_t msg_id, const uint8_t *data, uint8_t len);
void can_receive(uint16_t *msg_id, uint8_t *data, uint8_t *len);

#endif