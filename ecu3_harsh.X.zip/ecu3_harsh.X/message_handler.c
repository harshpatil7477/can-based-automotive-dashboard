
#include <xc.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"
#include "timer0.h"

volatile unsigned char led_state = LED_OFF, status = e_ind_off;


static void update_indicator_leds(void)
{
    PORTB &= 0x3C;

    if (led_state == LED_ON)
    {
        if (status == e_ind_left)
        {
            PORTB |= 0x03;
        }
        else if (status == e_ind_right)
        {
            PORTB |= 0xC0;
        }
        else if (status == e_ind_park)
        {
            PORTB |= 0xC3;
        }
    }
}
static void num_to_str(uint16_t num, unsigned char *str, uint8_t width)
{
    uint8_t i;

    str[width] = '\0';

    for (i = width; i > 0; i--)
    {
        if (num != 0 || i == width)
        {
            str[i - 1] = (num % 10) + '0';
            num = num / 10;
        }
        else
        {
            str[i - 1] = ' ';
        }
    }
}

/* Line 2, col 0-2 */
void handle_speed_data(uint8_t *data, uint8_t len)
{
    if (len < 3)
        return;

    data[3] = '\0';

    clcd_print((char *)data, LINE2(0));
}

/* Line 2, col 5 */
void handle_gear_data(uint8_t *data, uint8_t len)
{
    static unsigned char prev_gear = 0;

    if (len < 1)
        return;

    if (data[0] == prev_gear)
        return;
    prev_gear = data[0];

    clcd_putch(data[0], LINE2(5));
}

/* Line 2, col 8-11 */
void handle_rpm_data(uint8_t *data, uint8_t len)
{
    static uint16_t prev_rpm = 0xFFFF;
    unsigned char buf[5];
    uint16_t rpm;

    if (len < 2)
        return;

    rpm = ((uint16_t)data[0] << 8) | data[1];

    if (rpm == prev_rpm)
        return;
    prev_rpm = rpm;

    num_to_str(rpm, buf, 4);
    clcd_print(buf, LINE2(8));
}

/* Line 2, col 13-15 : 0=off, 1=left, 2=right, 3=parking */
void handle_indicator_data(uint8_t *data, uint8_t len)
{
    if (len < 1)
        return;

    if (data[0] == status)
        return;

    status = data[0];

    led_state = LED_OFF;

    switch (status)
    {
        case e_ind_left:
            clcd_print(" <- ", LINE2(13));
            break;

        case e_ind_right:
            clcd_print(" -> ", LINE2(13));
            break;

        case e_ind_park:
            clcd_print("<->", LINE2(13));
            break;

        default:
            clcd_print("OFF", LINE2(13));
            break;
    }
}



void process_canbus_data(void)
{
    static unsigned char blink_count = 0;

    uint16_t msg_id = 0;
    uint8_t data[8];
    uint8_t len = 0;

    can_receive(&msg_id, data, &len);

    if (len != 0)
    {
        switch (msg_id)
        {
            case SPEED_MSG_ID:
                handle_speed_data(data, len);
                break;

            case GEAR_MSG_ID:
                handle_gear_data(data, len);
                break;

            case RPM_MSG_ID:
                handle_rpm_data(data, len);
                break;

            case INDICATOR_MSG_ID:
                handle_indicator_data(data, len);
                break;

            default:
                break;
        }
    }

    if (status == e_ind_off)
    {
        led_state = LED_OFF;
        blink_count = 0;
        PORTB &= 0x3C;
    }
    else
    {
        if (timer0_tick_flag)
        {
            timer0_tick_flag = 0;

            blink_count++;

            if (blink_count >= 50)
            {
                blink_count = 0;
                led_state = !led_state;
            }
        }

        PORTB &= 0x3C;

        if (led_state == LED_ON)
        {
            if (status == e_ind_left)
            {
                PORTB |= 0x03;
            }
            else if (status == e_ind_right)
            {
                PORTB |= 0xC0;
            }
            else if (status == e_ind_park)
            {
                PORTB |= 0xC3;
            }
        }
    }
}